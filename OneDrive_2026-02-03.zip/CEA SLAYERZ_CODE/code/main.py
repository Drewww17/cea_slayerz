import pygame
import sys
from settings import *
from level import Level
from pygame import Surface
from pygame.transform import smoothscale, scale
from ui import UI
import level

first_wave_completed = False
second_wave_started = False

class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WIDTH, HEIGTH))
        pygame.display.set_caption('CEA Slayerz')
        self.clock = pygame.time.Clock()
        self.showing_instructions = False
        self.second_wave_started = False  # Declaration of the variable here

        self.level = Level()
        self.ui = UI()

        # Sound
        self.main_sound = pygame.mixer.Sound('../audio/main.ogg')
        self.main_sound.set_volume(0.5)
        self.main_sound.play(loops=-1)

        # Show instructions for 10 seconds
        self.ui.show_instructions()

    def game_over_screen(self):
        background = Surface(self.screen.get_size())
        background.blit(self.screen, (0, 0))
        blurred_background = smoothscale(background, (WIDTH // 10, HEIGTH // 10))
        blurred_background = scale(blurred_background, (WIDTH, HEIGTH))
        game_over_image = pygame.image.load('GameOver.png').convert_alpha()
        image_rect = game_over_image.get_rect(center=(WIDTH // 2, HEIGTH // 2))
        self.screen.blit(blurred_background, (0, 0))
        self.screen.blit(game_over_image, image_rect)
        pygame.display.flip()
        restart = False
        while not restart:
            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_r:
                        restart = True
                    elif event.key == pygame.K_n:
                        pygame.quit()
                        pygame.display.update()
                        return

        # Reset game
        self.level.player.health = 100
        self.level = Level()

    def win_screen(self):
        background = Surface(self.screen.get_size())
        background.blit(self.screen, (0, 0))
        blurred_background = smoothscale(background, (WIDTH // 10, HEIGTH // 10))
        blurred_background = scale(blurred_background, (WIDTH, HEIGTH))
        win_image = pygame.image.load('Win.png').convert_alpha()
        image_rect = win_image.get_rect(center=(WIDTH // 2, HEIGTH // 2))
        self.screen.blit(blurred_background, (0, 0))
        self.screen.blit(win_image, image_rect)
        pygame.display.flip()
        restart = False
        while not restart:
            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_r:
                        restart = True
                    elif event.key == pygame.K_n:
                        pygame.quit()
                        pygame.display.update()
                        return

        self.level.player.health = 100
        self.level = Level()

    def show_start_menu(self):
        background_image = pygame.image.load('MENU BACKGROUND.png').convert_alpha()
        menu_image = pygame.image.load('Main Menu 1.png').convert_alpha()
        background_rect = background_image.get_rect()
        menu_rect = menu_image.get_rect(center=(WIDTH // 2, HEIGTH // 2))

        self.screen.blit(background_image, background_rect)

        # Only display instructions
        self.ui.show_instructions()

        self.screen.blit(menu_image, menu_rect)

        # Display "Next Wave" message if the second wave has been started and game is restarted
        if self.second_wave_started and first_wave_completed:
            self.start_next_wave()

        pygame.display.flip()
    def show_game_instructions(self):
        instructions_text = ["Instructions:", "Move: WASD", "Attack: Spacebar", "Press 'Esc' to resume game"]
        font = pygame.font.Font(None, 36)
        text_color = 'WHITE'
        y = HEIGTH // 2
        for line in instructions_text:
            text = font.render(line, True, text_color)
            text_rect = text.get_rect(center=(WIDTH // 2, y))
            self.screen.blit(text, text_rect)
            y += 50

        pygame.display.update()

    def start_next_wave(self):
        background = Surface(self.screen.get_size())
        background.blit(self.screen, (0, 0))
        blurred_background = smoothscale(background, (WIDTH // 10, HEIGTH // 10))
        blurred_background = scale(blurred_background, (WIDTH, HEIGTH))
        game_over_image = pygame.image.load('NextWave.jpg').convert_alpha()
        image_rect = game_over_image.get_rect(center=(WIDTH // 2, HEIGTH // 2))
        self.screen.blit(blurred_background, (0, 0))
        self.screen.blit(game_over_image, image_rect)
        pygame.display.flip()
        restart = False
        while not restart:
            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE:
                        restart = True
                    elif event.key == pygame.K_n:
                        pygame.quit()
                        pygame.display.update()
                        return

        # Reset game
        self.level.player.health = 100
        self.level = Level()

    def run(self):
        self.show_start_menu()
        pygame.display.update()

        game_started = False

        while not game_started:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN and not self.showing_instructions:
                        game_started = True
                    elif event.key == pygame.K_i and not self.showing_instructions:
                        self.show_game_instructions()
                        self.showing_instructions = True
                    elif event.key == pygame.K_q:
                        pygame.quit()
                        sys.exit()
                    elif event.key == pygame.K_ESCAPE:
                        if not self.showing_instructions:
                            self.show_start_menu()
                            pygame.display.update()
                            game_started = True
                            break
                        else:
                            self.show_start_menu()
                            pygame.display.update()
                            self.showing_instructions = False

        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

            if self.level.player.health <= 0:
                self.game_over_screen()

            if self.level.player.exp >= 50000 and not self.second_wave_started:
                self.level.run()
                first_wave_completed = True
                if first_wave_completed:
                    self.second_wave_started = True
                    self.start_next_wave()  # Display "Next Wave" message
                    pygame.display.update()

            if self.second_wave_started and self.level.player.exp >= 50000:
                self.win_screen()  # Display win screen after reaching 100000 exp
                pygame.display.update()

            # Fill the screen with the background color before displaying the game content
            self.screen.fill(WATER_COLOR)
            self.level.run()
            pygame.display.update()
            self.clock.tick(FPS)


if __name__ == '__main__':
    game = Game()
    game.run()
