<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Objects" tilewidth="1792" tileheight="960" tilecount="17" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="80" height="80" source="../NEW GRAPHICS/Folder/0.png"/>
 </tile>
 <tile id="1">
  <image width="255" height="255" source="../NEW GRAPHICS/Folder/01.png"/>
 </tile>
 <tile id="2">
  <image width="255" height="255" source="../NEW GRAPHICS/Folder/02.png"/>
 </tile>
 <tile id="3">
  <image width="1792" height="896" source="../NEW GRAPHICS/Folder/03.png"/>
 </tile>
 <tile id="4">
  <image width="64" height="64" source="../NEW GRAPHICS/Folder/04.png"/>
 </tile>
 <tile id="5">
  <image width="64" height="64" source="../NEW GRAPHICS/Folder/05.png"/>
 </tile>
 <tile id="6">
  <image width="64" height="80" source="../NEW GRAPHICS/Folder/06.png"/>
 </tile>
 <tile id="7">
  <image width="64" height="64" source="../NEW GRAPHICS/Folder/07.png"/>
 </tile>
 <tile id="8">
  <image width="64" height="64" source="../NEW GRAPHICS/Folder/08.png"/>
 </tile>
 <tile id="9">
  <image width="20" height="64" source="../NEW GRAPHICS/Folder/09.png"/>
 </tile>
 <tile id="10">
  <image width="64" height="64" source="../NEW GRAPHICS/Folder/10.png"/>
 </tile>
 <tile id="11">
  <image width="64" height="64" source="../NEW GRAPHICS/Folder/11.png"/>
 </tile>
 <tile id="12">
  <image width="64" height="64" source="../NEW GRAPHICS/Folder/12.png"/>
 </tile>
 <tile id="13">
  <image width="64" height="64" source="../NEW GRAPHICS/Folder/13.png"/>
 </tile>
 <tile id="14">
  <image width="64" height="80" source="../NEW GRAPHICS/Folder/06.png"/>
 </tile>
 <tile id="15">
  <image width="64" height="80" source="../NEW GRAPHICS/Folder/15.png"/>
 </tile>
 <tile id="16">
  <image width="1792" height="960" source="../NEW GRAPHICS/Folder/16.png"/>
 </tile>
</tileset>
