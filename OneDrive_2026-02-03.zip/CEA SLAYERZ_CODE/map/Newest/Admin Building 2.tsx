<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Admin Building 2" tilewidth="64" tileheight="64" tilecount="392" columns="28">
 <image source="../../graphics/NEW GRAPHICS/Admin Building 2.png" width="1792" height="896"/>
</tileset>
