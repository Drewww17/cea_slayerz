<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="ENEMIES" tilewidth="119" tileheight="128" tilecount="5" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="64" height="64" source="../../graphics/monsters/bamboo/idle/0.png"/>
 </tile>
 <tile id="1">
  <image width="119" height="128" source="../../graphics/monsters/raccoon/idle/0.png"/>
 </tile>
 <tile id="2">
  <image width="64" height="64" source="../../graphics/monsters/spirit/idle/0.png"/>
 </tile>
 <tile id="3">
  <image width="64" height="64" source="../../graphics/monsters/squid/idle/0.png"/>
 </tile>
 <tile id="4">
  <image width="64" height="64" source="../../graphics/player/down_idle/idle_down.png"/>
 </tile>
</tileset>
